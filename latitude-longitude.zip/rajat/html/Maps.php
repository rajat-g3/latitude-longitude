<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<a href='index.html' class='btn btn-primary' align='right'>Back to Search</a></div>
<?php

class Maps
{
    const requestDenied = "REQUEST_DENIED";

    /**
     * Function To display Latitude and Longitude using Google Maps
     *
     * @param string $address
     * @param string $apiKey
     *
     * @return bool
     */
    public function getGoogleAddress($address, $apiKey)
    {
        if (empty($address) === true) {
            return false;
        }
        $address = str_replace(" ", "+", $address);

        $url = "http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&key=$apiKey";
        try {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0");
            $json = curl_exec($ch);
            curl_close($ch);
            $json = json_decode($json, true);

            if ($json["status"] === self::requestDenied) {
                echo "<br/><h1 class='text-primary'>Google Maps</h1><br/>";
                echo "<div class='alert alert-danger' role='alert'>";
                echo $json["error_message"];
                echo "</div>";
                return false;
            }

            //$string = file_get_contents("test.json");
            //$json = json_decode($string, true);

            $lat = $json["results"][0]["geometry"]["location"]["lat"] ;
            $lon = $json["results"][0]["geometry"]["location"]["lng"];

            if (isset($_POST['address']) === true) {
                echo "<br/><h1 class='text-primary'>Google Maps</h1><br/>";
                echo "<div class='form-group row form-horizontal'><div class='col-xs-3 col-lg-offset-4'><label for='latitude'>Latitude:</label><input type='text' class='form-control' value='$lat' readonly/></div></div><br/>";
                echo "<div class='form-group row form-horizontal'><div class='col-xs-3 col-lg-offset-4'><label for='latitude'>Longitude:</label><input type='text' class='form-control' value='$lon' readonly/></div></div><br/>";
                return true;
            }
        }
        catch(Exception $ex)
        {
            echo "There seems to be some problem while calling Google Maps";
        }
    }

    /**
     * Function To display Latitude and Longitude using Open Street Maps
     *
     * @param string $address
     *
     * @return bool
     */
    public function getOsmAddress($address)
    {
        if (empty($address) === true) {
            return false;
        }
        $address = str_replace(" ", "+", $address);

        $url = "https://nominatim.openstreetmap.org/?format=json&addressdetails=1&q={$address}&format=json&limit=1";
        try {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0");
            $jsonfile = curl_exec($ch);
            $resp = json_decode($jsonfile, true);
            if (empty($resp) === true) {
                echo "<br><h1 class='text-primary'>Open Street Map</h1><br/>";
                echo "<div class='alert alert-danger' role='alert'>";
                echo "Could not find the address. Please enter a valid address";
                echo "</div>";
                return false;
            }

            $lat = $resp[0]['lat'];
            $lon = $resp[0]['lon'];
            if (isset($address) === true) {
                echo "<br><h1 class='text-primary'>Open Street Map</h1><br/>";
                echo "<div class='form-group row form-horizontal'><div class='col-xs-3 col-lg-offset-4'><label for='latitude'>Latitude:</label><input type='text' class='form-control' value='$lat' readonly/></div></div><br/>";
                echo "<div class='form-group row form-horizontal'><div class='col-xs-3 col-lg-offset-4'><label for='latitude'>Longitude:</label><input type='text' class='form-control' value='$lon' readonly/></div></div><br/><hr/>";
                return true;
            }
        }
        catch(Exception $ex)
        {
            echo "There seems to be some problem while calling OSM";
        }
    }
}

$index = new Maps();
$ini = parse_ini_file('config/application.ini');
$apiKey = $ini["api_key"];
$address = $_POST['address'];
if (empty($address) === false) {
    $index->getOsmAddress($address);
    $index->getGoogleAddress($address, $apiKey);
}
