<?php

require 'vendor/autoload.php';
require_once "Maps.php";

class MapsTest extends \PHPUnit\Framework\TestCase
{
    /**
     *
     * @dataProvider getGoogleAddressDataProvider
     * @param string $address
     * @param string $apiKey
     * @param bool $expectedOutput
     */
    public function testGetGoogleAddress($address, $apiKey, $expectedOutput)
    {
        $googleMaps = new Maps();
        $result = $googleMaps->getGoogleAddress($address, $apiKey);
        $this->assertEquals($expectedOutput, $result);
    }

    public function getGoogleAddressDataProvider()
    {
        return array(
            // No address
            array(
                "",
                "",
                false
            ),

            // No Api Key
            array(
                "Nepal",
                "",
                false
            )/*,

            // Valid address
            array(
                "Nepal",
                "",             //Enter a valid key
                true
            )*/
        );
    }

    /**
     *
     * @dataProvider getOsmAddressDataProvider
     * @param string $address
     * @param bool $expectedOutput
     */
    public function testGetOsmAddress($address, $expectedOutput)
    {
        $osmMaps = new Maps();
        $result = $osmMaps->getOsmAddress($address);
        $this->assertEquals($expectedOutput , $result);
    }

    public function getOsmAddressDataProvider()
    {
        return array(
            // No address
            array(
                "",
                false
            ),

            // Invalid address
            array(
                "abcd1234",
                false
            ),

            // Valid address
            array(
                "Nepal",
                true
            )
        );
    }
}
